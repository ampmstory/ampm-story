"""간체자 견본·따라쓰기·획순 단계 이미지 (데이터: hanzi-writer-data ← Make Me a Hanzi, Arphic Public License)
사용: python3 render_glyphs_zh.py 你好我是人..."""
import json, os, sys, cairosvg

SRC = "/home/claude/zhdata/pkg/package"
OUT = os.environ.get("GLYPH_OUT", "/home/claude/glyphs")
DARK, TRACE, SOLID, PREV, PINK = "#4A3F45", "#CDBFC5", "#857980", "#D9D1D5", "#E57F91"
if os.environ.get("GLYPH_COLORS"):   # 테마별 색: DARK,TRACE,SOLID,PREV,ACCENT
    DARK, TRACE, SOLID, PREV, PINK = os.environ["GLYPH_COLORS"].split(",")
T = 'transform="translate(0,900) scale(1,-1)"'

def svg(body):
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="-40 -40 1104 1104">{body}</svg>'

def fill(paths, color):
    return f'<g {T}>' + "".join(f'<path d="{d}" fill="{color}"/>' for d in paths) + "</g>"

def save(name, body, px=300):
    cairosvg.svg2png(bytestring=svg(body).encode(), write_to=f"{OUT}/{name}.png", output_width=px, output_height=px)

def render(ch, counts):
    d = json.load(open(f"{SRC}/{ch}.json", encoding="utf-8"))
    st, med = d["strokes"], d["medians"]
    cp = f"{ord(ch):05x}"
    body = fill(st, DARK)
    placed = []
    for k, m in enumerate(med):                      # 획순 번호: 획 시작점 바깥쪽에 두고, 겹치면 밀어냄
        x0, y0 = m[0][0], 900 - m[0][1]
        x1, y1 = m[1][0], 900 - m[1][1]
        dx, dy = x0 - x1, y0 - y1
        L = max((dx * dx + dy * dy) ** 0.5, 1)
        x, y = x0 + dx / L * 55, y0 + dy / L * 55
        for _ in range(40):
            hit = [(px, py) for px, py in placed if (px - x) ** 2 + (py - y) ** 2 < 88 ** 2]
            if not hit: break
            px, py = hit[0]
            vx, vy = x - px, y - py
            vl = max((vx * vx + vy * vy) ** 0.5, 1)
            if vl < 2: vx, vy, vl = -1, 0, 1
            x, y = x + vx / vl * 25, y + vy / vl * 25
        x = min(max(x, 0), 1024); y = min(max(y, -10), 1010)
        placed.append((x, y))
        body += (f'<circle cx="{x}" cy="{y}" r="38" fill="{PINK}"/>'
                 f'<text x="{x}" y="{y + 19}" font-size="54" font-family="Arial" font-weight="bold" fill="#FFFFFF" text-anchor="middle">{k+1}</text>')
    save(f"{cp}_model", body)
    save(f"{cp}_plain", fill(st, DARK))
    save(f"{cp}_trace", fill(st, TRACE))
    save(f"{cp}_solid", fill(st, SOLID))
    for k in range(len(st)):
        b = fill(st[:k], PREV) + fill([st[k]], PINK)
        x, y = med[k][0][0], 900 - med[k][0][1]
        b += f'<circle cx="{x}" cy="{y}" r="40" fill="{DARK}"/>'
        save(f"{cp}_step{k+1}", b, px=200)
    counts[ch] = len(st)

if __name__ == "__main__":
    cpath = f"{OUT}/counts.json"
    counts = json.load(open(cpath, encoding="utf-8")) if os.path.exists(cpath) else {}
    for ch in "".join(sys.argv[1:]):
        render(ch, counts)
    json.dump(counts, open(cpath, "w", encoding="utf-8"), ensure_ascii=False)
    print({c: counts[c] for c in "".join(sys.argv[1:])})
