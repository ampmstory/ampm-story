AMPM STORY 간체자 획순 이미지 (174자)

이 이미지는 Make Me a Hanzi 프로젝트의 획 데이터(hanzi-writer-data 2.0.1 배포본)를 바탕으로 만든 것입니다.
원본 획 데이터는 Arphic Technology의 AR PL 글꼴에서 나왔으며 Arphic Public License로 배포됩니다.
이 이미지들도 같은 Arphic Public License(ARPHICPL.TXT)로 누구나 무료로 받을 수 있게 공개합니다.

바꾼 내용
- 획 색상 · 굵기 변경
- 단계별 획순 이미지(stepN)로 재구성
- 획순 번호 표시 추가(model)

파일 이름: 유니코드 코드포인트(16진수 5자리)_종류.png
  model = 획순 번호 견본, plain = 견본, trace = 따라 쓰기용 연한 글자, solid = 회색 칸용, stepN = N번째 획 단계
만든 스크립트: render_glyphs_zh.py (함께 들어 있음)

원본: https://github.com/skishore/makemeahanzi
라이선스 전문: ARPHICPL.TXT
글자 목록: 一七三上下不两个中为么九也习书买了事二五人什今他付以们会住作你停儿入八六共兴再写几分刷办务十午半单卡去口叫可右吃同名后吗吧听员和哥哪四国在地块多大天太女她好妈姐子字学客家对小少岁工左帮年店很慢懂我手打护拍按支敏文日早时是晚月有服机来比气汉没洗点照爱爸现生用男百的看碗站米给舒茶药菜要订认识语说请谢贵起车辣边过还这远遍那金钟钱铁长问间韩预题饭马骂高麻
